# backend/app/main.py
from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from sqlalchemy import text

from app.db.session import SessionLocal
from app.core.auth import auth_required
from app.api.routes import contacts, messages
from app.api.routes.login import router as login_router

app = FastAPI(title="Nexo_PPAM API", version="1.3.0")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"ok": True, "name": "Nexo_PPAM API", "version": app.version}

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/ready")
def ready():
    try:
        db = SessionLocal()
        db.execute(text("SELECT 1"))
        db.close()
        return {"ready": True}
    except Exception as e:
        return {"ready": False, "error": str(e)}

# Public
app.include_router(login_router, prefix="/api/v1", tags=["Auth"])

# Protected
app.include_router(
    contacts.router,
    prefix="/api/v1/contacts",
    tags=["Contacts"],
    dependencies=[Depends(auth_required)]
)
app.include_router(
    messages.router,
    prefix="/api/v1/messages",
    tags=["Messages"],
    dependencies=[Depends(auth_required)]
)

# OpenAPI Authorize (Bearer)
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description="API Nexo_PPAM",
        routes=app.routes,
    )
    components = openapi_schema.setdefault("components", {})
    components["securitySchemes"] = {
        "BearerAuth": {"type": "http", "scheme": "bearer", "bearerFormat": "JWT"}
    }
    openapi_schema["security"] = [{"BearerAuth": []}]
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi
