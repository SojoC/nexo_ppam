# backend/app/api/routes/login.py
from datetime import datetime, timedelta
import os
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from jose import jwt

router = APIRouter()

ALGO = "HS256"
SECRET = os.getenv("JWT_SECRET", "dev-secret")

class LoginBody(BaseModel):
    username: str
    password: str

@router.post("/login")
def login(body: LoginBody):
    USER = os.getenv("DEMO_USER", "admin")
    PASS = os.getenv("DEMO_PASS", "admin")
    if body.username != USER or body.password != PASS:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    exp = datetime.utcnow() + timedelta(hours=8)
    token = jwt.encode({"sub": body.username, "exp": exp}, SECRET, algorithm=ALGO)
    return {"access_token": token, "token_type": "bearer"}
