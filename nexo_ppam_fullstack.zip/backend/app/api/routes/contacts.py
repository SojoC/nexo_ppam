# backend/app/api/routes/contacts.py
from typing import Optional, List
from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select, func, or_
from starlette.responses import Response, PlainTextResponse
import csv, io

from app.core.auth import auth_required
from app.db.deps import get_db
from app.db.models import Contact
from app.search.matcher import build_search_stmt, _unaccent_func

router = APIRouter()

@router.get("")
def list_contacts(
    q: Optional[str] = Query(default=None, description="Texto a buscar"),
    limit: int =  Query(default=100, ge=1, le=2000),
    offset: int = Query(default=0, ge=0),
    order_by: str = Query(default="nombre", description="nombre|congregacion|circuito"),
    direction: str = Query(default="asc", description="asc|desc"),
    circuito: Optional[str] = None,
    congregacion: Optional[str] = None,
    db: Session = Depends(get_db),
    _user=Depends(auth_required),
):
    stmt = select(Contact)
    if q:
        stmt = build_search_stmt(db, q, limit=limit).offset(offset)
        # order will be applied later; build_search_stmt selects columns
        rows = db.execute(stmt).all()
        # simple ordering on client side fields
        key = {"nombre": 1, "congregacion": 3, "circuito": 2}.get(order_by, 1)
        rows.sort(key=lambda x: (x[key] or "").lower(), reverse=(direction=="desc"))
        return [
            {"id": r[0], "nombre": r[1], "telefono": r[2], "circuito": r[3], "congregacion": r[4]}
            for r in rows
        ]

    # filters without q
    if circuito:
        stmt = stmt.where(Contact.circuito == circuito)
    if congregacion:
        stmt = stmt.where(Contact.congregacion == congregacion)

    col = getattr(Contact, order_by, Contact.nombre)
    if direction.lower() == "desc":
        col = col.desc()
    stmt = stmt.order_by(col).limit(limit).offset(offset)
    return [{
        "id": c.id, "nombre": c.nombre, "telefono": c.telefono,
        "circuito": c.circuito, "congregacion": c.congregacion
    } for c in db.execute(stmt).scalars().all()]


@router.get("/suggest")
def suggest(
    q: str = Query(..., min_length=1),
    max_items: int = Query(8, ge=1, le=20),
    db: Session = Depends(get_db),
    _user=Depends(auth_required),
):
    iu = _unaccent_func(db)
    like = f"%{q}%"
    stmt = (
        select(Contact.nombre)
        .where(iu(Contact.nombre).ilike(iu(like)))
        .order_by(Contact.nombre.asc())
        .limit(max_items)
    )
    names = [n for (n,) in db.execute(stmt).all() if n]
    return names


@router.get("/by-phone")
def by_phone(
    phone: str = Query(..., min_length=1),
    match: str = Query("exact", pattern="^(exact|prefix)$"),
    db: Session = Depends(get_db),
    _user=Depends(auth_required),
):
    like = phone if match == "exact" else f"{phone}%"
    comp = Contact.telefono == like if match == "exact" else Contact.telefono.ilike(like)
    stmt = select(Contact).where(comp).limit(50)
    items = db.execute(stmt).scalars().all()
    return [{
        "id": c.id, "nombre": c.nombre, "telefono": c.telefono,
        "circuito": c.circuito, "congregacion": c.congregacion
    } for c in items]


@router.get("/stats")
def stats(
    days: int = Query(30, ge=1, le=365),
    top_k: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
    _user=Depends(auth_required),
):
    # Simple: top_k por congregación
    stmt = (
        select(Contact.congregacion, func.count().label("n"))
        .group_by(Contact.congregacion)
        .order_by(func.count().desc())
        .limit(top_k)
    )
    rows = db.execute(stmt).all()
    return [{"congregacion": r[0], "count": r[1]} for r in rows]


@router.get("/stats.csv")
def stats_csv(
    days: int = Query(30, ge=1, le=365),
    top_k: int = Query(10, ge=1, le=100),
    delimiter: str = Query("comma", pattern="^(comma|semicolon)$"),
    excel_compat: bool = Query(False),
    db: Session = Depends(get_db),
    _user=Depends(auth_required),
):
    data = stats(days=days, top_k=top_k, db=db, _user=_user)
    output = io.StringIO()
    delim = ";" if delimiter == "semicolon" else ","
    writer = csv.DictWriter(output, fieldnames=["congregacion", "count"], delimiter=delim)
    writer.writeheader()
    writer.writerows(data)
    text = output.getvalue()
    if excel_compat and delim == ";":
        text = "\ufeff" + text  # BOM + semicolon suele abrir bien en Excel LATAM
    return PlainTextResponse(text, media_type="text/csv")


@router.get("/export")
def export_contacts(
    q: Optional[str] = None,
    circuito: Optional[str] = None,
    congregacion: Optional[str] = None,
    delimiter: str = Query("comma", pattern="^(comma|semicolon)$"),
    excel_compat: bool = Query(False),
    limit: int = Query(2000, ge=1, le=100000),
    db: Session = Depends(get_db),
    _user=Depends(auth_required),
):
    # Construimos dataset
    if q:
        rows = list_contacts(q=q, limit=limit, db=db, _user=_user)  # reusa lógica
    else:
        stmt = select(Contact)
        if circuito: stmt = stmt.where(Contact.circuito == circuito)
        if congregacion: stmt = stmt.where(Contact.congregacion == congregacion)
        stmt = stmt.order_by(Contact.nombre.asc()).limit(limit)
        rows = [{
            "id": c.id, "nombre": c.nombre, "telefono": c.telefono,
            "circuito": c.circuito, "congregacion": c.congregacion
        } for c in db.execute(stmt).scalars().all()]

    output = io.StringIO()
    delim = ";" if delimiter == "semicolon" else ","
    writer = csv.DictWriter(output, fieldnames=["id","nombre","telefono","circuito","congregacion"], delimiter=delim)
    writer.writeheader()
    writer.writerows(rows)
    text = output.getvalue()
    if excel_compat and delim == ";":
        text = "\ufeff" + text
    return PlainTextResponse(text, media_type="text/csv")
