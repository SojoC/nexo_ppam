# backend/app/api/routes/messages.py
from fastapi import APIRouter, Depends
from app.core.auth import auth_required

router = APIRouter()

@router.get("/")
def list_messages(_=Depends(auth_required)):
    return []
