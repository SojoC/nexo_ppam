# backend/app/core/auth.py
import os
from fastapi import Header, HTTPException, status
from jose import jwt, JWTError

ALGO = "HS256"
SECRET = os.getenv("JWT_SECRET", "dev-secret")

def auth_required(authorization: str = Header(None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Auth required")
    token = authorization.split(" ", 1)[1]
    try:
        payload = jwt.decode(token, SECRET, algorithms=[ALGO])
        return payload
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
