# backend/app/search/matcher.py
from sqlalchemy import select, or_, func, text
from sqlalchemy.orm import Session
from app.db.models import Contact

def _supports(db: Session, fn: str) -> bool:
    try:
        result = db.execute(text("SELECT to_regprocedure(:p)"), {"p": f"{fn}(text)"}).scalar()
        return result is not None
    except Exception:
        return False

def _unaccent_func(db: Session):
    # Prefer immutable wrapper if exists, fallback to plain unaccent, else identity
    if _supports(db, "immutable_unaccent"):
        return func.immutable_unaccent
    if _supports(db, "unaccent"):
        return func.unaccent
    return lambda x: x  # identity

def build_search_stmt(db: Session, term: str, limit: int = 300):
    iu = _unaccent_func(db)
    like = f"%{term}%"
    stmt = (
        select(Contact.id, Contact.nombre, Contact.telefono, Contact.circuito, Contact.congregacion)
        .where(
            or_(
                iu(Contact.nombre).ilike(iu(like)),
                iu(Contact.congregacion).ilike(iu(like)),
                iu(Contact.circuito).ilike(iu(like)),
                Contact.telefono.ilike(like),
            )
        )
        .limit(limit)
    )
    return stmt
