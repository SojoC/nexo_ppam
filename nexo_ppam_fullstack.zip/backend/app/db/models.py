# backend/app/db/models.py
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import JSON, String

class Base(DeclarativeBase):
    pass

class Contact(Base):
    __tablename__ = "contacts"
    id: Mapped[int] = mapped_column(primary_key=True)
    nombre: Mapped[str | None] = mapped_column(String)
    telefono: Mapped[str | None] = mapped_column(String)
    circuito: Mapped[str | None] = mapped_column(String)
    congregacion: Mapped[str | None] = mapped_column(String)
    territorio: Mapped[str | None] = mapped_column(String)
    privilegios: Mapped[str | None] = mapped_column(String)
    metadata: Mapped[dict | None] = mapped_column(JSON)
