# Nexo_PPAM – Full Stack (FastAPI + Vite React)

## Requisitos
- Docker y Docker Compose
- Puertos libres: 5432 (Postgres), 6379 (Redis), 8000 (API), 5173 (Frontend)

## Levantar todo
```bash
docker compose up -d db redis
# Primer arranque de DB crea extensiones y tabla (init.sql)
docker compose up -d api
docker compose up -d web
```

Frontend: http://localhost:5173  
API docs: http://localhost:8000/docs

## Login
En `/api/v1/login` con:
```
{"username": "admin", "password": "admin"}
```
(Variables en `backend/.env.example`)

En `/docs` pulsa **Authorize** y coloca `Bearer <token>`.

## Endpoints clave
- `GET /health`, `GET /ready`
- `POST /api/v1/login` → obtiene token
- `GET /api/v1/contacts` → lista/busca (q, limit, offset, order_by, direction, filtro por `circuito` y `congregacion`)
- `GET /api/v1/contacts/suggest?q=...`
- `GET /api/v1/contacts/by-phone?phone=...&match=exact|prefix`
- `GET /api/v1/contacts/stats?days=30&top_k=10`
- `GET /api/v1/contacts/stats.csv?...` (opciones `delimiter=semicolon` y `excel_compat=true`)
- `GET /api/v1/contacts/export?...`

## Notas
- Se crea `immutable_unaccent(text)` para poder indexar trigram con `unaccent`.
- Si ya tenías un volumen previo de Postgres y no ves las extensiones, borra el volumen (dev only):
  ```bash
  docker compose down
  docker volume rm $(basename "$PWD")_dbdata
  docker compose up -d db
  ```
