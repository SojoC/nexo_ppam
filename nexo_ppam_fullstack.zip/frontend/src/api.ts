const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000'

export function getToken(): string | null {
  return localStorage.getItem('token')
}

export function setToken(t: string) {
  localStorage.setItem('token', t)
}

export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers: any = { 'Content-Type': 'application/json', ...(options.headers || {}) }
  const token = getToken()
  if (token) headers['Authorization'] = `Bearer ${token}`
  const res = await fetch(`${API_BASE}${path}`, { ...options, headers })
  if (!res.ok) {
    const msg = await res.text()
    throw new Error(`${res.status} ${res.statusText}: ${msg}`)
  }
  if (res.headers.get('content-type')?.includes('application/json')) {
    return res.json()
  }
  // @ts-ignore
  return res.text()
}

export async function login(username: string, password: string) {
  return api<{ access_token: string, token_type: string }>(`/api/v1/login`, {
    method: 'POST',
    body: JSON.stringify({ username, password }),
  })
}
