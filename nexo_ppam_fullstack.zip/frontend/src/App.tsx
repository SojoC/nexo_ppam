import React, { useEffect, useState } from 'react'
import Navbar from './components/Navbar'
import Login from './pages/Login'
import Contacts from './pages/Contacts'
import Stats from './pages/Stats'
import { getToken, setToken } from './api'

export default function App() {
  const [route, setRoute] = useState<string>(location.hash || '#/contacts')
  const [authed, setAuthed] = useState<boolean>(!!getToken())

  useEffect(() => {
    const onHash = () => setRoute(location.hash || '#/contacts')
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])

  function logout() {
    setToken('')
    localStorage.removeItem('token')
    setAuthed(false)
  }

  if (!authed) return <Login onSuccess={()=>setAuthed(true)} />

  return (
    <div>
      <div className="container"><Navbar onLogout={logout} /></div>
      {route.startsWith('#/stats') ? <Stats/> : <Contacts/>}
    </div>
  )
}
