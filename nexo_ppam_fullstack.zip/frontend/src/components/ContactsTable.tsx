import React from 'react'

type Contact = {
  id: number
  nombre: string | null
  telefono: string | null
  circuito: string | null
  congregacion: string | null
}

export default function ContactsTable({ data }: { data: Contact[] }) {
  return (
    <div className="card">
      <table>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Teléfono</th>
            <th>Circuito</th>
            <th>Congregación</th>
          </tr>
        </thead>
        <tbody>
          {data.map(c => (
            <tr key={c.id}>
              <td>{c.nombre}</td>
              <td>{c.telefono}</td>
              <td>{c.circuito}</td>
              <td>{c.congregacion}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
