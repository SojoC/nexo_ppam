import React from 'react'

export default function Navbar({ onLogout }: { onLogout: () => void }) {
  return (
    <div className="card" style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
      <div style={{fontWeight:700}}>Nexo_PPAM</div>
      <div className="row">
        <a href="#/contacts">Contactos</a>
        <a href="#/stats">Estadísticas</a>
        <button onClick={onLogout}>Salir</button>
      </div>
    </div>
  )
}
