import React, { useEffect, useState } from 'react'
import { api } from '../api'

type Row = { congregacion: string | null, count: number }

export default function Stats() {
  const [rows, setRows] = useState<Row[]>([])

  async function load() {
    const res = await api<Row[]>(`/api/v1/contacts/stats?days=60&top_k=15`)
    setRows(res)
  }

  async function downloadCsv() {
    const text = await api<string>(`/api/v1/contacts/stats.csv?days=60&top_k=15&delimiter=semicolon&excel_compat=true`)
    const blob = new Blob([text], {type: 'text/csv;charset=utf-8'})
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'stats.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  useEffect(()=>{ load() }, [])

  return (
    <div className="container">
      <div className="card" style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <div><b>Top congregaciones</b></div>
        <button onClick={downloadCsv}>Descargar CSV</button>
      </div>
      <div className="space"></div>
      <div className="card">
        <table>
          <thead><tr><th>Congregación</th><th>Cantidad</th></tr></thead>
          <tbody>
            {rows.map((r,i)=> (<tr key={i}><td>{r.congregacion}</td><td>{r.count}</td></tr>))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
