import React, { useState } from 'react'
import { login, setToken } from '../api'

export default function Login({ onSuccess }: { onSuccess: () => void }) {
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('admin')
  const [err, setErr] = useState<string>('')

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setErr('')
    try {
      const res = await login(username, password)
      setToken(res.access_token)
      onSuccess()
    } catch (e: any) {
      setErr(e.message)
    }
  }

  return (
    <div className="container">
      <div className="space"></div>
      <form onSubmit={submit} className="card" style={{maxWidth:480, margin:'0 auto'}}>
        <h2>Ingresar</h2>
        <div className="space"></div>
        <div className="row"><label style={{width:90}}>Usuario</label><input value={username} onChange={e=>setUsername(e.target.value)} /></div>
        <div className="row"><label style={{width:90}}>Clave</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} /></div>
        <div className="space"></div>
        {err && <div style={{color:'#f88'}}>{err}</div>}
        <div className="space"></div>
        <button type="submit">Entrar</button>
      </form>
    </div>
  )
}
