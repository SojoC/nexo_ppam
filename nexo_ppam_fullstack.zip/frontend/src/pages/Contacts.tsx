import React, { useEffect, useState } from 'react'
import { api } from '../api'
import ContactsTable from '../components/ContactsTable'

type Contact = {
  id: number
  nombre: string | null
  telefono: string | null
  circuito: string | null
  congregacion: string | null
}

export default function Contacts() {
  const [q, setQ] = useState('')
  const [data, setData] = useState<Contact[]>([])
  const [loading, setLoading] = useState(false)

  async function fetchData() {
    setLoading(true)
    try {
      const qs = q ? `?q=${encodeURIComponent(q)}` : ''
      const res = await api<Contact[]>(`/api/v1/contacts${qs}`)
      setData(res)
    } finally {
      setLoading(false)
    }
  }

  async function exportCsv() {
    const qs = q ? `?q=${encodeURIComponent(q)}&excel_compat=true&delimiter=semicolon` : '?excel_compat=true&delimiter=semicolon'
    const text = await api<string>(`/api/v1/contacts/export${qs}`)
    const blob = new Blob([text], {type: 'text/csv;charset=utf-8'})
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'contacts.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  useEffect(() => { fetchData() }, [])

  return (
    <div className="container">
      <div className="card">
        <div className="row">
          <input placeholder="Buscar..." value={q} onChange={e=>setQ(e.target.value)} onKeyDown={(e)=>{ if(e.key==='Enter') fetchData() }} />
          <button onClick={fetchData} disabled={loading}>{loading ? 'Buscando...' : 'Buscar'}</button>
          <button onClick={exportCsv}>Exportar CSV</button>
        </div>
      </div>
      <div className="space"></div>
      <ContactsTable data={data} />
    </div>
  )
}
